#!/usr/bin/python3
import string
import sys
import argparse
import os.path

global errors
errors = 0

MAX_KEY_SIZE = 26
ALPHABET_U = (string.ascii_uppercase)
ALPHABET_L = (string.ascii_lowercase)
PUNCTUATION = string.punctuation


"""
User input functions
"""


msg = ""
file_name = ""

global parser


def inputs():
    global parser, args
    parser = argparse.ArgumentParser()
    parser.add_argument('modein', help='mode')
    parser.add_argument('shift', help='shift value')
    parser.add_argument('message',nargs='+', action='store', help='message needed to code')
    parser.add_argument('-f', '--file')
    parser.add_argument('-w', '--write')
    args = parser.parse_args()

    print(args)

    return parser, args


def get_cipher_mode():
    """
    Gets user input for the cipher mode. Must be either encrypt, e, decrypt or d.

    Returns cipher_mode as a string.
    """
    global cipher_mode
    while True:
        cipher_mode = args.modein
        if cipher_mode in "encrypt e decrypt d".split():
            return cipher_mode
        else:
            print("This is an error message\n", file=sys.stderr)
            return errors + 1
        return cipher_mode


def get_shift_value():
    """
    Gets user input for the shift value. Must be a positive integer.

    Returns shift_value as an int.
    """
    while True:
        shift_value = args.shift
        #print(shift_value)
        if not shift_value.isdigit():
            print("This is an error message\n", file=sys.stderr)
            return errors + 1
        elif int(shift_value) < 0:
            print("This is an error message\n", file=sys.stderr)
            return errors + 1
        else:
            return int(shift_value)


def get_msg():
    """
    Gets user input for the text. It continues reading in input until the user
    inputs an empty line (i.e. double enter).
    """

    line = args.message

    while line != "":
        msg = line
        #print("1111111111" + msg)
        return msg
    #print("1111111111" + msg)
    return msg

"""
File usage functions
"""


def ret_file_msg(file_name):
    file_read = open(file_name, "r")
    line = file_read.read()
    return line


def write_msg_to_file(file_name, msg):
    out = open(file_name, "w")
    out.write(msg)
    print('File:' + file_name + ' created')


"""
Cipher functions
"""

def translate_msg(shift_value, msg):
    """
    Performs the Caesar cipher on a string converted to upper case with the given shift.

    shift_value : int
        shift amount/rotation value for the cipher. Positive encrypts and negative decrypts.
    msg : str
        message to be translated
    
    Returns the translated message as a string.
    """
    translated_msg = ''

    for symbol in msg:
        if symbol.isalpha():
            if symbol.isupper():
                position = ALPHABET_U.index(symbol)
                new_symbol = ALPHABET_U[(position + int(shift_value)) % MAX_KEY_SIZE]
                translated_msg += new_symbol
                #print('translated upper')
            else:
                position = ALPHABET_L.index(symbol)
                #print(shift_value)
                new_symbol = ALPHABET_L[(position + int(shift_value)) % MAX_KEY_SIZE]
                translated_msg += new_symbol
                #print('translated lower')
        else:
            translated_msg += symbol

    return translated_msg
    

def caesar_encrypt(shift_value, msg):
    """
    Wrapper function for translate_msg
    
    N.B. shift value kept positive for encryption.
    """
    #print('encrypting')
    return translate_msg(shift_value, msg)
    

def caesar_decrypt(shift_value, msg):
    """
    Wrapper function for translate_msgmsg = ""
    
    N.B. shift value becomes negative for decryption.
    """
    #print('decrypting')
    return translate_msg(-int(shift_value), msg)


"""
Main function
"""


def main():
    inputs()
    cipher_mode = get_cipher_mode()
    shift_value = get_shift_value()
    msg = str.join(' ', get_msg())
    #print(msg)
    if cipher_mode == "e":
        translated_msg = caesar_encrypt(shift_value, msg)
        #print("mode=" + cipher_mode)
    if not cipher_mode == "e":
        translated_msg = caesar_decrypt(shift_value, msg)

    if args.write != None:
        file_name = args.write
        write_msg_to_file(file_name, translated_msg)
    if args.write == None:
        print(translated_msg)

    quit()


if __name__ == '__main__':
    main()


